namespace DotaHeroes.Models;

/// <summary>
/// Абстрактный базовый класс всех героев.
/// Доступ к данным — только через свойства (геттеры/сеттеры) с валидацией.
/// </summary>
public abstract class Hero
{
    private string _name = "Unknown";
    private int _health = 100;
    private int _damage = 10;

    public int Id { get; set; }

    public string Name
    {
        get => _name;
        set => _name = string.IsNullOrWhiteSpace(value) ? "Unknown" : value.Trim();
    }

    public int Health
    {
        get => _health;
        set => _health = Math.Max(0, value);
    }

    public int Damage
    {
        get => _damage;
        set => _damage = Math.Max(0, value);
    }

    /// <summary>Читаемая роль героя (для таблицы).</summary>
    public abstract string RoleName { get; }

    /// <summary>Специфическая информация (для таблицы).</summary>
    public string SpecificInfo => GetSpecificInfo();

    /// <summary>Статус героя (для таблицы).</summary>
    public string StatusText => IsAlive() ? "Жив" : "Погиб";

    protected Hero() { }

    protected Hero(int id, string name, int health, int damage)
    {
        Id = id;
        Name = name;
        Health = health;
        Damage = damage;
    }

    protected Hero(string name, int health, int damage)
    {
        Name = name;
        Health = health;
        Damage = damage;
    }

    /// <summary>Конструктор копирования.</summary>
    protected Hero(Hero other)
    {
        Name = other.Name;
        Health = other.Health;
        Damage = other.Damage;
    }

    // ---- чисто абстрактные методы ----

    /// <summary>Атака другого героя. Возвращает текст-лог действия.</summary>
    public abstract string Attack(Hero target);

    /// <summary>Применение способности. Возвращает текст-лог действия.</summary>
    public abstract string UseAbility();

    // ---- виртуальные методы ----

    public virtual string GetInfo() => $"[{Name}] HP: {Health} | DMG: {Damage}";

    public virtual string GetSpecificInfo() => "Базовый герой";

    // ---- обычные методы ----

    public string TakeDamage(int amount)
    {
        if (amount < 0) amount = 0;
        Health -= amount;
        return $"{Name} получает {amount} урона. Осталось HP: {Health}";
    }

    public bool IsAlive() => Health > 0;
}
