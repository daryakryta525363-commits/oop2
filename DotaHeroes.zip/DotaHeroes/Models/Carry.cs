namespace DotaHeroes.Models;

/// <summary>Керри — герой, основная задача которого наносить урон.</summary>
public class Carry : Hero
{
    private int _critChance = 15;
    private int _agility = 10;

    /// <summary>Шанс критического удара в процентах (0–100).</summary>
    public int CritChance
    {
        get => _critChance;
        set => _critChance = Math.Clamp(value, 0, 100);
    }

    public int Agility
    {
        get => _agility;
        set => _agility = Math.Max(0, value);
    }

    public override string RoleName => "Керри";

    public Carry()
        : base("New Carry", 120, 20)
    {
    }

    public Carry(int id, string name, int health, int damage, int critChance, int agility)
        : base(id, name, health, damage)
    {
        CritChance = critChance;
        Agility = agility;
    }

    public Carry(string name, int health, int damage, int critChance, int agility)
        : base(name, health, damage)
    {
        CritChance = critChance;
        Agility = agility;
    }

    public Carry(Carry other) : base(other)
    {
        CritChance = other.CritChance;
        Agility = other.Agility;
    }

    public override string Attack(Hero target)
    {
        if (!IsAlive()) return $"[Carry::Attack] {Name} погиб и не может атаковать.";

        int dmg = Damage;
        string prefix = $"[Carry::Attack] {Name} атакует {target.Name}. ";
        if (Random.Shared.Next(100) < CritChance)
        {
            dmg *= 2;
            prefix += "КРИТИЧЕСКИЙ УДАР! ";
        }
        return prefix + target.TakeDamage(dmg);
    }

    public override string UseAbility()
    {
        Agility += 5;
        return $"[Carry::UseAbility] {Name} повышает ловкость на 5. Ловкость: {Agility}";
    }

    public override string GetInfo()
        => $"{base.GetInfo()} | Роль: Керри | Крит: {CritChance}% | Ловкость: {Agility}";

    public override string GetSpecificInfo()
        => $"Крит: {CritChance}%, Ловкость: {Agility}";

    public bool CanCriticalHit() => CritChance > 0;

    public string IncreaseAgility(int amount)
    {
        if (amount <= 0) return "Значение должно быть положительным.";
        Agility += amount;
        return $"{Name}: ловкость увеличена на {amount}. Ловкость: {Agility}";
    }
}
