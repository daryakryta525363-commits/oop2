namespace DotaHeroes.Models;

/// <summary>Саппорт — герой поддержки: мана и лечение.</summary>
public class Support : Hero
{
    private const int AbilityCost = 50;

    private int _mana = 200;
    private int _healPower = 30;

    public int Mana
    {
        get => _mana;
        set => _mana = Math.Max(0, value);
    }

    public int HealPower
    {
        get => _healPower;
        set => _healPower = Math.Max(0, value);
    }

    public override string RoleName => "Саппорт";

    public Support()
        : base("New Support", 90, 8)
    {
    }

    public Support(int id, string name, int health, int damage, int mana, int healPower)
        : base(id, name, health, damage)
    {
        Mana = mana;
        HealPower = healPower;
    }

    public Support(string name, int health, int damage, int mana, int healPower)
        : base(name, health, damage)
    {
        Mana = mana;
        HealPower = healPower;
    }

    public Support(Support other) : base(other)
    {
        Mana = other.Mana;
        HealPower = other.HealPower;
    }

    public override string Attack(Hero target)
    {
        if (!IsAlive()) return $"[Support::Attack] {Name} погиб и не может атаковать.";

        return $"[Support::Attack] {Name} запускает магический снаряд в {target.Name}. "
               + target.TakeDamage(Damage);
    }

    public override string UseAbility()
    {
        if (!HasEnoughMana(AbilityCost))
            return $"[Support::UseAbility] Недостаточно маны! Нужно {AbilityCost}, есть {Mana}.";

        Mana -= AbilityCost;
        Health += HealPower;
        return $"[Support::UseAbility] {Name} лечит себя на {HealPower}. HP: {Health}, мана: {Mana}";
    }

    public override string GetInfo()
        => $"{base.GetInfo()} | Роль: Саппорт | Мана: {Mana} | Лечение: {HealPower}";

    public override string GetSpecificInfo()
        => $"Мана: {Mana}, Лечение: {HealPower}";

    public bool HasEnoughMana(int cost) => Mana >= cost;

    public string RegenerateMana(int amount)
    {
        if (amount <= 0) return "Значение должно быть положительным.";
        Mana += amount;
        return $"{Name}: мана восстановлена на {amount}. Мана: {Mana}";
    }
}
