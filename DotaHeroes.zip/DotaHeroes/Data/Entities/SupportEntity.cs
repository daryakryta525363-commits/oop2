namespace DotaHeroes.Data.Entities;

/// <summary>Таблица Supports: специфические данные саппорта.</summary>
public class SupportEntity
{
    public int Id { get; set; }

    public int HeroId { get; set; }

    public int Mana { get; set; }

    public int HealPower { get; set; }

    public HeroEntity? Hero { get; set; }
}
