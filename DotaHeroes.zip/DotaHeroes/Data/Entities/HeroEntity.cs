using System.ComponentModel.DataAnnotations;

namespace DotaHeroes.Data.Entities;

/// <summary>Главная таблица Heroes: общие данные любого героя.</summary>
public class HeroEntity
{
    public int Id { get; set; }

    [Required]
    public string Name { get; set; } = string.Empty;

    public int Health { get; set; }

    public int Damage { get; set; }

    /// <summary>Дискриминатор типа: "Carry" или "Support".</summary>
    public string HeroType { get; set; } = string.Empty;

    public CarryEntity? CarryData { get; set; }

    public SupportEntity? SupportData { get; set; }
}
