using System.ComponentModel.DataAnnotations;

namespace DotaHeroes.Data.Entities;

/// <summary>Таблица Carries: специфические данные керри.</summary>
public class CarryEntity
{
    public int Id { get; set; }

    public int HeroId { get; set; }

    [Range(0, 100)]
    public int CritChance { get; set; }

    public int Agility { get; set; }

    public HeroEntity? Hero { get; set; }
}
