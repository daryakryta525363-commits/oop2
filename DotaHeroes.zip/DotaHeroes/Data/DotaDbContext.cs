using DotaHeroes.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace DotaHeroes.Data;

public class DotaDbContext : DbContext
{
    // !!! Поменяйте пароль (и при необходимости хост/порт) на свои !!!
    public const string ConnectionString =
        "Host=localhost;Port=5432;Database=DotaHeroesDB;Username=postgres;Password=1111";

    public DbSet<HeroEntity> Heroes { get; set; }
    public DbSet<CarryEntity> Carries { get; set; }
    public DbSet<SupportEntity> Supports { get; set; }

    /// <summary>Конструктор с параметрами подключения (внедряются снаружи).</summary>
    public DotaDbContext(DbContextOptions<DotaDbContext> options) : base(options) { }

    /// <summary>Конструктор без параметров: используется приложением и инструментом миграций.</summary>
    public DotaDbContext() : base(CreateOptions()) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Связь один-к-одному с каскадным удалением
        modelBuilder.Entity<CarryEntity>()
            .HasOne(c => c.Hero)
            .WithOne(h => h.CarryData)
            .HasForeignKey<CarryEntity>(c => c.HeroId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<SupportEntity>()
            .HasOne(s => s.Hero)
            .WithOne(h => h.SupportData)
            .HasForeignKey<SupportEntity>(s => s.HeroId)
            .OnDelete(DeleteBehavior.Cascade);
    }

    private static DbContextOptions<DotaDbContext> CreateOptions()
    {
        var builder = new DbContextOptionsBuilder<DotaDbContext>();
        builder.UseNpgsql(ConnectionString);
        return builder.Options;
    }
}
