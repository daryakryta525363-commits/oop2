using DotaHeroes.Data.Entities;
using DotaHeroes.Models;

namespace DotaHeroes.Data;

/// <summary>Преобразование между моделями (Hero) и сущностями БД (HeroEntity).</summary>
public static class HeroMapper
{
    public const string CarryType = "Carry";
    public const string SupportType = "Support";

    /// <summary>Сущность БД -> объект бизнес-логики.</summary>
    public static Hero ToModel(HeroEntity e)
    {
        if (e.HeroType == CarryType && e.CarryData != null)
        {
            return new Carry(e.Id, e.Name, e.Health, e.Damage,
                e.CarryData.CritChance, e.CarryData.Agility);
        }

        if (e.HeroType == SupportType && e.SupportData != null)
        {
            return new Support(e.Id, e.Name, e.Health, e.Damage,
                e.SupportData.Mana, e.SupportData.HealPower);
        }

        throw new InvalidOperationException($"Герой Id={e.Id}: нет данных для типа '{e.HeroType}'.");
    }

    /// <summary>Объект бизнес-логики -> новая сущность БД.</summary>
    public static HeroEntity ToEntity(Hero hero)
    {
        var entity = new HeroEntity();
        UpdateEntity(entity, hero);
        return entity;
    }

    /// <summary>Обновляет сущность данными из объекта бизнес-логики (при смене типа заменяет дочернюю запись).</summary>
    public static void UpdateEntity(HeroEntity entity, Hero hero)
    {
        entity.Name = hero.Name;
        entity.Health = hero.Health;
        entity.Damage = hero.Damage;

        if (hero is Carry c)
        {
            entity.HeroType = CarryType;
            entity.SupportData = null;
            entity.CarryData ??= new CarryEntity();
            entity.CarryData.CritChance = c.CritChance;
            entity.CarryData.Agility = c.Agility;
        }
        else if (hero is Support s)
        {
            entity.HeroType = SupportType;
            entity.CarryData = null;
            entity.SupportData ??= new SupportEntity();
            entity.SupportData.Mana = s.Mana;
            entity.SupportData.HealPower = s.HealPower;
        }
    }
}
